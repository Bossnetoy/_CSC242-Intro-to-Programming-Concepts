/*
 * Name: Kenneth R. Heintzelman
 * Assignment 5, Random Monoalphabetc Cipher
 * Course: CSC242
 * Date: 6/21/2026
 * Purpose:
 * Encrypt or decrypt a file using a random monoalphabetic cipher.
 */

#include <iostream>
#include <fstream>
#include <string>
#include <cctype>

using namespace std;

string removeDuplicates(string key)
{
    string result = "";

    for (int i = 0; i < key.length(); i++)
    {
        char ch = toupper(key[i]);

        if (result.find(ch) == string::npos)
        {
            result += ch;
        }
    }

    return result;
}

string createCipherAlphabet(string key)
{
    string alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    key = removeDuplicates(key);

    for (int i = 25; i >= 0; i--)
    {
        if (key.find(alphabet[i]) == string::npos)
        {
            key += alphabet[i];
        }
    }

    return key;
}

int main()
{
    string key;

    cout << "Enter keyword: ";
    cin >> key;

    string cipher = createCipherAlphabet(key);

    cout << "Cipher alphabet: " << cipher << endl;

    return 0;
}
