/*
 * Name: Kenneth R. Heintzelman
 * Assignment 5, Spell Checker
 * Course CSC242
 * Date: 6/21/2026
 * Purpose:
 * Check the spelling of words in a file by comparing
 * them with words stored in a dictionary.
 */

#include <iostream>
#include <fstream>
#include <vector>
#include <string>

using namespace std;

int main()
{
    vector<string> words;
    ifstream dictionaryFile("dictionary.txt");

    if (!dictionaryFile)
    {
        cout << "Error opening dictionary file." << endl;
        return 1;
    }

    string word;

    while (dictionaryFile >> word)
    {
        words.push_back(word);
    }

    dictionaryFile.close();

    ifstream inputFile("input.txt");

    if (!inputFile)
    {
        cout << "Error opening input file." << endl;
        return 1;
    }

    cout << "Misspelled words:" << endl;

    while (inputFile >> word)
    {
        bool found = false;

        for (int i = 0; i < words.size(); i++)
        {
            if (word == words[i])
            {
                found = true;
                break;
            }
        }

        if (!found)
        {
            cout << word << endl;
        }
    }

    inputFile.close();

    return 0;
}
